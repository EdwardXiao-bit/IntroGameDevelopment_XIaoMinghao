using UnityEngine;
using UnityEngine.InputSystem;

public class ObjectController : MonoBehaviour
{
    public GameObject obj1;
    public GameObject obj2;
    public GameObject obj3;
    public GameObject obj4;

    public float moveSpeed = 20f;

    void Update()
    {
        if (Keyboard.current.qKey.wasPressedThisFrame)
            Application.Quit();

        float vertical = 0f;
        if (Keyboard.current.upArrowKey.isPressed)
            vertical = 1f;
        else if (Keyboard.current.downArrowKey.isPressed)
            vertical = -1f;

        if (Mathf.Abs(vertical) < 0.01f) return;

        MoveAndScale(obj1, 1f, 1f, vertical);
        MoveAndScale(obj2, -1f, 1f, vertical);
        MoveAndScale(obj3, 1f, -1f, vertical);
        MoveAndScale(obj4, -1f, -1f, vertical);
    }

    void MoveAndScale(GameObject obj, float dirX, float dirY, float v)
    {
        Vector3 pos = obj.transform.position;
        pos.x += dirX * v * moveSpeed * Time.deltaTime;
        pos.y += dirY * v * moveSpeed * Time.deltaTime;

        pos.x = Mathf.Clamp(pos.x, dirX > 0 ? 1f : -50f, dirX > 0 ? 50f : -1f);
        pos.y = Mathf.Clamp(pos.y, dirY > 0 ? 1f : -50f, dirY > 0 ? 50f : -1f);
        obj.transform.position = pos;

        float s = v * 0.1f;
        Vector3 scale = obj.transform.localScale + new Vector3(s, s, s);
        scale.x= Mathf.Clamp(scale.x, 1f, 6f);
        scale.y = Mathf.Clamp(scale.y, 1f, 6f);
        scale.z = Mathf.Clamp(scale.z, 1f, 6f);
        obj.transform.localScale = scale;
    }
}